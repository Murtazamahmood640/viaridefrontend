import React from 'react'

const VehicleRequestDetails = () => {
  return (
    <div>VehicleRequestDetails</div>
  )
}

export default VehicleRequestDetails;