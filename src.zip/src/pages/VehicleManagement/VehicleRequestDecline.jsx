import React from 'react'

const VehicleRequestDecline = () => {
  return (
    <div>VehicleRequestDecline</div>
  )
}

export default VehicleRequestDecline;