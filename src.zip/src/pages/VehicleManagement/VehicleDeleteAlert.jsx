import React from 'react'

const VehicleDeleteAlert = () => {
  return (
    <div>VehicleDeleteAlert</div>
  )
}

export default VehicleDeleteAlert;