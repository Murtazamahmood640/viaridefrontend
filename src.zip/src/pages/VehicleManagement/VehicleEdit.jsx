import React from 'react'

const VehicleEdit = () => {
  return (
    <div>VehicleEdit</div>
  )
}

export default VehicleEdit;