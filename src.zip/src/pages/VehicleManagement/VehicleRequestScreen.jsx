import React from 'react'

const VehicleRequestScreen = () => {
  return (
    <div>VehicleRequestScreen</div>
  )
}

export default VehicleRequestScreen;