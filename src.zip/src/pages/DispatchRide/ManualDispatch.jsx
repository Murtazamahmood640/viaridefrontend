import React from 'react'

const ManualDispatch = () => {
  return (
    <div>ManualDispatch</div>
  )
}

export default ManualDispatch;