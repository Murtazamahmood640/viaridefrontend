import React from 'react'

const BookingDetails = () => {
  return (
    <div>BookingDetails</div>
  )
}

export default BookingDetails;